﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Library
{
    public partial class Form2 : Form
    {
        Book book = null;
        bool isAddOrEdit;
        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Book book, bool isAddOrEdit)
        {
            InitializeComponent();
            this.book = book;
            this.isAddOrEdit = isAddOrEdit;
            if (!isAddOrEdit)
            {
                textBox1.Text = book.Name;
                textBox2.Text = book.Autor;
                textBox3.Text = book.Genre;
                textBox4.Text = book.Year.ToString();
                textBox5.Text = book.CountOfPages.ToString();
                Text = "Edit Book";
            }
            else
            {
                Text = "Add Book";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            book.Name = textBox1.Text;
            book.Autor = textBox2.Text;
            book.Genre = textBox3.Text;
            book.Year = int.Parse(textBox4.Text);
            book.CountOfPages = int.Parse(textBox5.Text);
            DialogResult = DialogResult.OK;
        }
        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
