﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book_Library
{
    [Serializable]
    public class Book
    {
        public string Name { get; set; }
        public string Autor {  get; set; } 
        public string Genre {  get; set; }
        public int Year {  get; set; }
        public int CountOfPages { get; set; }
        public Book() { }
        public Book(string name, string autor, string genre, int year, int countOfPages)
        {
            Name = name;
            Autor = autor;
            Genre = genre;
            Year = year;
            CountOfPages = countOfPages;
        }

        public override string ToString() 
        {
            return $"Name: {Name}\nAutor: {Autor}\nGenre: {Genre}\nYear: {Year}\nCount of pages: {CountOfPages}";
        }
    }
}
