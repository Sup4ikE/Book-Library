﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_Library
{
    public partial class Form3 : Form
    {
        public List<Book> Books { get; set; }
        public Form3()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = true;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = true;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = true;
            textBox5.Enabled = false;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show(
            "Yes = Ascending No = Descending",
            "Sort Options",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question
                );
            if (result == DialogResult.Yes)
            {
                if (radioButton1.Checked)
                {
                    var sortedBooks = Books.OrderBy(book => book.Name).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by name");
                }
                if (radioButton2.Checked)
                {
                    var sortedBooks = Books.OrderBy(book => book.Autor).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by autor");
                }
                if (radioButton3.Checked)
                {
                    var sortedBooks = Books.OrderBy(book => book.Genre).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by genre");
                }
                if (radioButton4.Checked)
                {
                    var sortedBooks = Books.OrderBy(book => book.Year.ToString()).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by year");
                }
                if (radioButton5.Checked)
                {
                    var sortedBooks = Books.OrderBy(book => book.CountOfPages.ToString()).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by count of pages");
                }
            }
            else if (result == DialogResult.No)
            {
                if (radioButton1.Checked)
                {
                    var sortedBooks = Books.OrderByDescending(book => book.Name).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by name");
                }
                if (radioButton2.Checked)
                {
                    var sortedBooks = Books.OrderByDescending(book => book.Autor).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by autor");
                }
                if (radioButton3.Checked)
                {
                    var sortedBooks = Books.OrderByDescending(book => book.Genre).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by genre");
                }
                if (radioButton4.Checked)
                {
                    var sortedBooks = Books.OrderByDescending(book => book.Year.ToString()).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by year");
                }
                if (radioButton5.Checked)
                {
                    var sortedBooks = Books.OrderByDescending(book => book.CountOfPages.ToString()).ToList();
                    string sortedBooksStr = string.Join("\n", sortedBooks.Select(b => b));
                    MessageBox.Show(sortedBooksStr, "Sorted books by count of pages");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true && textBox1.Text != "")
            {
                for (int i = 0; i < Books.Count; i++)
                {
                    if (Books[i].Name == textBox1.Text)
                    {
                        MessageBox.Show("Searched book:\n" + Books[i].ToString());
                    }
                }
            }
            if (radioButton2.Checked == true && textBox2.Text != "")
            {
                for (int i = 0; i < Books.Count; i++)
                {
                    if (Books[i].Autor == textBox2.Text)
                    {
                        MessageBox.Show("Searched book:\n" + Books[i].ToString());
                    }
                }
            }
            if (radioButton3.Checked == true && textBox3.Text != "")
            {
                for (int i = 0; i < Books.Count; i++)
                {
                    if (Books[i].Genre == textBox3.Text)
                    {
                        MessageBox.Show("Searched book:\n" + Books[i].ToString());
                    }
                }
            }
            if (radioButton4.Checked == true && textBox4.Text != "")
            {
                for (int i = 0; i < Books.Count; i++)
                {
                    if (Books[i].Year.ToString() == textBox4.Text)
                    {
                        MessageBox.Show("Searched book:\n" + Books[i].ToString());
                    }
                }
            }
            if (radioButton5.Checked == true && textBox5.Text != "")
            {
                for (int i = 0; i < Books.Count; i++)
                {
                    if (Books[i].CountOfPages.ToString() == textBox5.Text)
                    {
                        MessageBox.Show("Searched book:\n" + Books[i].ToString());
                    }
                }
            }
        }
    }
}
