using System.Xml.Serialization;

namespace Book_Library
{
    public partial class Form1 : Form
    {
        List<Book> books = new List<Book>();
        Book book = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            book = new Book();
            Form2 addForm = new Form2(book, true);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items.Add(book);
                books.Add(book);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            book = (Book)listBox1.SelectedItem;

            Form2 editForm = new Form2(book, false);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items[listBox1.SelectedIndex] = book;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = listBox1.SelectedIndices.Count - 1; i >= 0; i--)
            {
                int selectedIndex = listBox1.SelectedIndices[i];
                listBox1.Items.RemoveAt(selectedIndex);
                books.RemoveAt(selectedIndex);
            }

            var sr = new XmlSerializer(typeof(List<Book>));
            using (FileStream fs = new FileStream("books.xml", FileMode.Create))
            {
                sr.Serialize(fs, books);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3
            {
                Books = this.books 
            };

            form3.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3
            {
                Books = this.books
            };

            form3.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int countOfBooks = listBox1.Items.Count;

            int pages = 0;
            for (int i = 0; i < countOfBooks; i++)
            {
                pages += books[i].CountOfPages;
            }
            int arfPages = pages / countOfBooks;

            var mostPopGenre = books
                .GroupBy(book => book.Genre)
                .OrderByDescending(group => group.Count())
                .FirstOrDefault()?.Key;

            MessageBox.Show($"Statistic:\nCount of Books - {countOfBooks}\nArf of Pages - {arfPages}\nMost popular genre - {mostPopGenre}");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Serialize();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            books = Deserialize();
            foreach (Book book in books)
            {
                listBox1.Items.Add(book);
            }
        }


        // Xml
        public void Serialize()
        {
            var sr = new XmlSerializer(typeof(List<Book>));

            using (FileStream fs = new FileStream("books.xml", FileMode.Open))
            {
                sr.Serialize(fs, books);
                MessageBox.Show("Books add to file!");
            }
        }
        public List<Book> Deserialize()
        {
            string path = "books.xml";

            var sr = new XmlSerializer(typeof(List<Book>));

            using (FileStream fs = new FileStream("books.xml", FileMode.Open))
            {
                return sr.Deserialize(fs) as List<Book>;
            }
        }
    }
}